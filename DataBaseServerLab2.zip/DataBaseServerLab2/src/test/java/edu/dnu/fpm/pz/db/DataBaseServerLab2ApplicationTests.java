package edu.dnu.fpm.pz.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataBaseServerLab2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
