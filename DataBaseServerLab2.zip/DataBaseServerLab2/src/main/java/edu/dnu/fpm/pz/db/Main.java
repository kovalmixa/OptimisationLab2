package edu.dnu.fpm.pz.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {
        "edu.dnu.fpm.pz.demohw",                  // твой основной модуль
        "edu.dnu.fpm.pz.controllershw7.controllers"  // где находятся контроллеры
})

@SpringBootApplication
public class Main {
    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }
}